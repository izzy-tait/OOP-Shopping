package login;

import java.awt.*;
import javax.swing.*;
import login.SellerAccount;

public class SellerHome extends JPanel {
	
    JLabel menuBar = new JLabel();
    JButton home = new JButton("Home");
    JButton Inventory = new JButton("Inventory");
    JLabel info = new JLabel();
    Color bg = new Color(221,221,221);
    JLabel profile = new JLabel();
    JLabel history = new JLabel();
    JLabel add = new JLabel("Shopping History");
    SellerAccount currentUser;
    JLabel profileName = new JLabel();
	
    public SellerHome() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	int width=(int)screenSize.getWidth();
        int height=(int)screenSize.getHeight();
        Color backGround= new Color(151, 186, 255);
	this.setBounds(width/8, 1, width-width/4, height);
		
	JLabel profilePic = new JLabel();
		
		
	menuBar.setBounds(0, 0, width-width/4, 100);
	menuBar.setBackground(backGround);
	menuBar.setOpaque(true);
	menuBar.setBorder(BorderFactory.createLineBorder(Color.black));
		
	this.add(menuBar);
		
		
	//Home label
	home.setBounds(0, 0, 200, 100);
	home.setBorder(BorderFactory.createLineBorder(Color.black));
	home.setLayout(null);
	home.setHorizontalAlignment(JTextField.CENTER);
		
	home.setFont(new Font("Arial", Font.BOLD, 35));
	home.setBackground(backGround);
	home.setOpaque(true);
	home.setForeground(Color.white);
		
	menuBar.add(home);
		
	//Let's Shop
	Inventory.setBounds(200, 0, 200, 100);
	Inventory.setBorder(BorderFactory.createLineBorder(Color.black));
	Inventory.setLayout(null);
	Inventory.setHorizontalAlignment(JLabel.CENTER);
		
	Inventory.setFont(new Font("Arial", Font.BOLD, 35));
	Inventory.setBackground(backGround);
	Inventory.setOpaque(true);
	Inventory.setForeground(Color.white);
		
	menuBar.add(Inventory);
		
	//Profile information
	info.setBounds(0, 100, width-width/4, height-100);
	info.setBackground(bg);
	info.setOpaque(true);
	info.setBorder(BorderFactory.createLineBorder(Color.black));
		
	this.add(info);
		
	//Profile section
	profile.setBounds(20, 70, (width-width/4)-40, height-300);
	profile.setBorder(BorderFactory.createLineBorder(Color.black));
	profile.setLayout(null);
	profile.setBackground(backGround);
	profile.setOpaque(true);
		
	info.add(profile);
		
		
		
	//Profile name
	profileName.setBounds(0, 0, (width-width/4)-40, 40);
	profileName.setBorder(BorderFactory.createLineBorder(Color.black));
	profileName.setHorizontalAlignment(JTextField.CENTER);
	profileName.setBackground(backGround);
	profileName.setOpaque(true);
		
	profileName.setFont(new Font("Arial", Font.BOLD, 35));
	profileName.setForeground(Color.white);
		
	profile.add(profileName);
		
	//Profile picture
	ImageIcon imgThisImg = new ImageIcon("src/App/pic/picture.png");

	profilePic.setIcon(imgThisImg);
	profilePic.setBounds(10, 50, 231, 257);
	profilePic.setOpaque(true);
	profilePic.setBorder(BorderFactory.createLineBorder(Color.black));
		
	profile.add(profilePic);

	this.setBackground(bg);
	this.setOpaque(true);
		
	this.setLayout(null);
		
	}
	
	public void display() {
		//profileName.setText(currentUser.firstName + " " + currentUser.lastName);
	}
	
	
}