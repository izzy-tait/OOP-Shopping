package login;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.ListIterator;

public class Account implements Serializable{
	
    private String username;
    private String password;
    private String firstName;
    private String lastName;
    	
    public Account(String auserName, String apassWord, String afirstName, String alastName) {
	username = auserName;
	password = apassWord;
	firstName = afirstName;
	lastName = alastName;
    }

    public String getUsername()
    {
       return username; 
    }

    public String getPassword()
    {
        return password;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public String getLastName()
    {
        return lastName;
    }
}