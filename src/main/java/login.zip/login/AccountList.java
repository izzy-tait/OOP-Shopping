package login;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.ListIterator;

public class AccountList implements Serializable {
    private LinkedList<Account> accounts;
    private ListIterator<Account> accountIterator;

    public AccountList()
    {
        accounts = new LinkedList<Account>();
        accountIterator = accounts.listIterator();
    }

    public LinkedList<Account> getAccounts()
    {
        return accounts; 
    }

    public void addAccount(Account anAccount)
    {
        accounts.add(anAccount);
    }
    public ListIterator<Account> iterate(){
        return accountIterator;
    }
}